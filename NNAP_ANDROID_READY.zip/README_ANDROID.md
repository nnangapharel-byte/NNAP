# NNAP Android

Projet Android prêt pour compilation par GitHub Actions.

## Depuis un téléphone
1. Créer un dépôt GitHub gratuit et privé nommé NNAP.
2. Envoyer tout le contenu de ce dossier dans le dépôt.
3. Ouvrir l'onglet Actions.
4. Choisir `Build NNAP APK`.
5. Appuyer sur `Run workflow`.
6. Une fois terminé, ouvrir le résultat `NNAP-debug-apk`.
7. Télécharger `app-debug.apk` puis l'installer sur Android.

Aucun abonnement GitHub payant n'est nécessaire pour ce workflow sur un dépôt personnel privé dans les limites gratuites du service.

La connexion TikTok réelle sera branchée après création/autorisation de l'application TikTok Developer.
